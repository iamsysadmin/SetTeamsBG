

Remove-Item 'C:\ProgramData\Set-RU-Teams-Backgrounds' -Recurse -force

Remove-Item $env:LOCALAPPDATA\Set-RU-Teams-BG-task-done -Recurse -force

schtasks /delete /TN "SetRUTeamsBGTask"

Start-Sleep -s 10

exit

