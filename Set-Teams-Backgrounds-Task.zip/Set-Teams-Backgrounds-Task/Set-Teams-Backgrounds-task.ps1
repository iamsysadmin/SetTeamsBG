# enter the share to the folder where the content of the script mentioned above will be in (Set-Teams-Backgrounds).

Copy-Item -path \\share-to-folder-Set-Teams-Backgrounds -Destination C:\ProgramData\Set-Teams-Backgrounds -recurse -force



Start-Sleep -s 10

# the command to create the task



schtasks /create /tn "SetTeamsBGTask" /XML C:\ProgramData\Set-RU-Teams-Backgrounds\SetTeamsBGTask.xml



Start-Sleep -s 10


# start the task


Start-ScheduledTask -TaskName "SetTeamsBGTask"


# Create the folder for MECM detection methode


new-item -itemtype "directory" -path $env:LOCALAPPDATA\Set-Teams-BG-task-done


# Create the txt file for MECM detection methode


new-item $env:LOCALAPPDATA\Set-Teams-BG-task-done\Set-Teams-BG-task-done.txt



exit
