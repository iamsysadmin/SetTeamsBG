# Script to copy content for task creation to run powershell script.
# Created by: Remy Kuster
# Website: www.iamsysadmin.eu
# Creation date: 02-07-2021

# Create variables

$sourcefolder = "{\\share-to-content-folder-Set-Teams-Backgrounds}" #Enter the share to the folder where the content of the script will be in (Set-Teams-Backgrounds).
$DirectorySetTBGToCreate = "$env:ProgramData\Set-Teams-Backgrounds"
$taskName = "SetTeamsBGTask"
$taskExists = Get-ScheduledTask | Where-Object {$_.TaskName -like $taskName }
$MECMDetectionFolder = "$env:LOCALAPPDATA\Set-Teams-BG-task-done"
$MECMDetecionFile = "Set-Teams-BG-task-done.txt"


# Check if $env:ProgramData\Set-Teams-Backgrounds is present, if not create folder

if (!(Test-Path -LiteralPath $DirectorySetTBGToCreate -PathType container)) 
    {
    
        try 
            {
                New-Item -Path $DirectorySetTBGToCreate -ItemType Directory -ErrorAction Stop | Out-Null #-Force
            }
        catch 
            {
                Write-Host -Message "Unable to create directory '$DirectorySetTBGToCreate' . Error was: $_" -ErrorAction Stop    
            }

    Write-Host "Successfully created directories '$DirectorySetTBGToCreate' ."
    }

else 
    {
        Write-Host "Directory '$DirectorySetTBGToCreate' already exist"
    }

# copy content from share to Set-Teams-Backgrounds folder

        Write-Host "Start copy action of uploads folder from share"
        $sourcefiles = (Get-ChildItem -Path $sourcefolder -erroraction SilentlyContinue).Name
        
        if($sourcefiles -ne $null)

        {
        
        foreach($sourcefile in $sourcefiles)
            { if(!(Test-Path $DirectorySetTBGToCreate\$sourcefile))

                       {
                        Copy-Item -Path $sourcefolder\$sourcefile -Destination $DirectorySetTBGToCreate\$sourcefile -Recurse -Force
                        if(Test-path -Path "$DirectorySetTBGToCreate\$sourcefile")
                            {
                                Write-Host "File $sourcefile was copied"
                            }
                        else
                            {
                                Write-Host "Failed to copy file $sourcefile"
                                Exit 1
                            }
                    }
                else
                    {
                        Write-Host "File $sourcefile already exists"
                    }            
                            
            }

                        }
            
        else

        {
        Write-Host "Failed to connect to $sourcefolder"
        exit
        }

Start-Sleep -s 10

# Create the task

if($taskExists) {

   
   Write-Host "$taskName already exists"
    
                } 

else  {

   schtasks /create /tn  $taskName /XML $env:ProgramData\Set-Teams-Backgrounds\SetTeamsBGTask.xml

   Start-Sleep -s 10


    #Start the task


    Start-ScheduledTask -TaskName "$taskName"

    # Create the folder for MECM detection methode


    new-item -itemtype "directory" -path $MECMDetectionFolder

   
    #Create the txt file for MECM detection methode


    new-item $MECMDetectionFolder\$MECMDetecionFile

        }


exit
